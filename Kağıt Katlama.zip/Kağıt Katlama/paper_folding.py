import pygame
import numpy as np
import sys

# Pygame başlatma
pygame.init()

# Ekran boyutları
WINDOW_SIZE = 800
screen = pygame.display.set_mode((WINDOW_SIZE, WINDOW_SIZE))
pygame.display.set_caption("Kağıt Katlama Simülasyonu")

# Renkler
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
GRAY = (200, 200, 200)
LIGHT_BLUE = (200, 220, 255)  # Katlanmamış kağıt rengi
DARKER_BLUE = (150, 170, 220)  # Katlanan kısım rengi
RED = (255, 0, 0)

# Kağıt boyutları ve pozisyonu
ORIGINAL_PAPER_SIZE = 600
PAPER_SIZE = ORIGINAL_PAPER_SIZE
paper_x = (WINDOW_SIZE - PAPER_SIZE) // 2
paper_y = (WINDOW_SIZE - PAPER_SIZE) // 2

# Oyun değişkenleri
paper_matrix = np.zeros((4, 4))
current_state = 0
fold_direction = None
holes = []
folded = False
folded_size = PAPER_SIZE  # Katlanan kağıdın boyutu

# Oyun durumları
FOLDING = 0
HOLE_PUNCHING = 1
UNFOLDING = 2

def reset_paper():
    global paper_x, paper_y, PAPER_SIZE, current_state, fold_direction, holes, folded, folded_size
    PAPER_SIZE = ORIGINAL_PAPER_SIZE
    paper_x = (WINDOW_SIZE - PAPER_SIZE) // 2
    paper_y = (WINDOW_SIZE - PAPER_SIZE) // 2
    current_state = FOLDING
    fold_direction = None
    holes = []
    folded = False
    folded_size = PAPER_SIZE

def draw_paper():
    if folded:
        if fold_direction == "vertical":
            # Sağdan sola katlama
            folded_width = PAPER_SIZE // 2
            # Katlanan kısım (üstteki katman)
            pygame.draw.rect(screen, DARKER_BLUE, 
                           (paper_x + folded_width, paper_y, folded_width, PAPER_SIZE))
            # Alt katman
            pygame.draw.rect(screen, LIGHT_BLUE, 
                           (paper_x, paper_y, folded_width, PAPER_SIZE))
            
        elif fold_direction == "horizontal":
            # Üstten alta katlama
            folded_height = PAPER_SIZE // 2
            # Katlanan kısım (üstteki katman)
            pygame.draw.rect(screen, DARKER_BLUE, 
                           (paper_x, paper_y + folded_height, PAPER_SIZE, folded_height))
            # Alt katman
            pygame.draw.rect(screen, LIGHT_BLUE, 
                           (paper_x, paper_y, PAPER_SIZE, folded_height))
            
        elif fold_direction == "diagonal":
            # Çapraz katlama
            points = [(paper_x, paper_y),  # Sol üst
                     (paper_x + PAPER_SIZE, paper_y),  # Sağ üst
                     (paper_x + PAPER_SIZE//2, paper_y + PAPER_SIZE//2)]  # Orta nokta
            # Alt katman (üçgen)
            pygame.draw.rect(screen, LIGHT_BLUE, 
                           (paper_x, paper_y, PAPER_SIZE, PAPER_SIZE))
            # Katlanan kısım (üstteki üçgen)
            pygame.draw.polygon(screen, DARKER_BLUE, points)
    else:
        # Katlanmamış kağıt
        pygame.draw.rect(screen, LIGHT_BLUE, 
                        (paper_x, paper_y, PAPER_SIZE, PAPER_SIZE))
    
    # Kağıdın çerçevesi
    pygame.draw.rect(screen, BLACK, 
                    (paper_x, paper_y, PAPER_SIZE, PAPER_SIZE), 2)
    
    # Katlama çizgileri (sadece katlanmamış durumda)
    if not folded:
        # Dikey çizgi
        pygame.draw.line(screen, GRAY, 
                        (paper_x + PAPER_SIZE//2, paper_y),
                        (paper_x + PAPER_SIZE//2, paper_y + PAPER_SIZE), 2)
        # Yatay çizgi
        pygame.draw.line(screen, GRAY, 
                        (paper_x, paper_y + PAPER_SIZE//2),
                        (paper_x + PAPER_SIZE, paper_y + PAPER_SIZE//2), 2)
        # Çapraz çizgi
        pygame.draw.line(screen, GRAY, 
                        (paper_x, paper_y),
                        (paper_x + PAPER_SIZE, paper_y + PAPER_SIZE), 2)

    # Delikleri çiz
    for hole in holes:
        x, y = hole
        pygame.draw.circle(screen, BLACK, (x, y), 10)

def draw_interface():
    font = pygame.font.Font(None, 36)
    
    if current_state == FOLDING:
        text = font.render("Katlama Yönü: 1-Sağ/Sol, 2-Üst/Alt, 3-Çapraz (R: Sıfırla)", True, BLACK)
    elif current_state == HOLE_PUNCHING:
        text = font.render("Delik Açmak İçin Tıklayın (Space: Bitir, R: Sıfırla)", True, BLACK)
    else:
        text = font.render("Kağıt Açıldı (R: Sıfırla)", True, BLACK)
    
    screen.blit(text, (10, 10))

def mirror_holes():
    global holes
    new_holes = []
    
    if fold_direction == "horizontal":
        for hole in holes:
            x, y = hole
            mirror_y = 2 * (paper_y + PAPER_SIZE//2) - y
            new_holes.append((x, mirror_y))
    elif fold_direction == "vertical":
        for hole in holes:
            x, y = hole
            mirror_x = 2 * (paper_x + PAPER_SIZE//2) - x
            new_holes.append((mirror_x, y))
    elif fold_direction == "diagonal":
        for hole in holes:
            x, y = hole
            dx = x - paper_x
            dy = y - paper_y
            new_holes.append((paper_x + dy, paper_y + dx))
    
    holes.extend(new_holes)

def main():
    global current_state, fold_direction, holes, folded, PAPER_SIZE, paper_x, paper_y
    
    running = True
    while running:
        screen.fill(WHITE)
        draw_paper()
        draw_interface()
        
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
                
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_r:
                    reset_paper()
                    
                elif current_state == FOLDING:
                    if event.key == pygame.K_1:
                        fold_direction = "vertical"
                        current_state = HOLE_PUNCHING
                        folded = True
                    elif event.key == pygame.K_2:
                        fold_direction = "horizontal"
                        current_state = HOLE_PUNCHING
                        folded = True
                    elif event.key == pygame.K_3:
                        fold_direction = "diagonal"
                        current_state = HOLE_PUNCHING
                        folded = True
                        
                elif current_state == HOLE_PUNCHING:
                    if event.key == pygame.K_SPACE:
                        mirror_holes()
                        current_state = UNFOLDING
                        folded = False
            
            if event.type == pygame.MOUSEBUTTONDOWN and current_state == HOLE_PUNCHING:
                x, y = pygame.mouse.get_pos()
                if paper_x <= x <= paper_x + PAPER_SIZE and paper_y <= y <= paper_y + PAPER_SIZE:
                    # Katlanan kısma göre delik kontrolü
                    valid_hole = False
                    if fold_direction == "vertical" and x >= paper_x + PAPER_SIZE//2:
                        valid_hole = True
                    elif fold_direction == "horizontal" and y >= paper_y + PAPER_SIZE//2:
                        valid_hole = True
                    elif fold_direction == "diagonal":
                        # Çapraz katlamada üçgen alan kontrolü
                        triangle_y = y - paper_y
                        triangle_x = x - paper_x
                        if triangle_y <= triangle_x:  # Üçgenin üst kısmında
                            valid_hole = True
                    
                    if valid_hole:
                        holes.append((x, y))
        
        pygame.display.flip()

    pygame.quit()
    sys.exit()

if __name__ == "__main__":
    main()
