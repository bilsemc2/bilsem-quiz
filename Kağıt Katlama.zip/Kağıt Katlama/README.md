# Kağıt Katlama Simülasyonu

Bu oyun, kare şeklinde bir kağıdı katlayıp delik açma ve sonuçlarını görüntüleme simülasyonudur.

## Özellikler

- Kağıdı üç farklı şekilde katlama:
  - Sağdan sola
  - Üstten alta
  - Sağ alt köşeden sol üst köşeye (çapraz)
- Katlanan kağıt üzerinde istediğiniz noktalara delik açma
- Delikler açıldıktan sonra kağıdın açık halini görüntüleme
- Oyunu sıfırlama ve yeniden başlama

## Kurulum

1. Gerekli kütüphaneleri yükleyin:
```bash
pip install -r requirements.txt
```

2. Oyunu başlatın:
```bash
python paper_folding.py
```

## Nasıl Oynanır?

1. Başlangıçta katlama yönünü seçin:
   - 1: Sağdan sola katlama
   - 2: Üstten alta katlama
   - 3: Çapraz katlama

2. Kağıt katlandıktan sonra, fare ile tıklayarak delikler açın
   - İstediğiniz kadar delik açabilirsiniz
   - Delik açma işlemini bitirmek için SPACE tuşuna basın

3. Kağıt açıldığında tüm deliklerin son halini göreceksiniz
   - Yeniden başlamak için R tuşuna basın

4. Oyundan çıkmak için pencereyi kapatın
